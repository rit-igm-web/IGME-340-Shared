package com.example.class_template

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
