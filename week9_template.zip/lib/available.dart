import 'package:flutter/material.dart';
import "globals.dart";
import 'active.dart';

class AvailableAbilitiesPage extends StatefulWidget {
  const AvailableAbilitiesPage({super.key});

  @override
  State<AvailableAbilitiesPage> createState() => _AvailableAbilitiesPageState();
}

class _AvailableAbilitiesPageState extends State<AvailableAbilitiesPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Available Abilities'),
      ),
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.white,
                Colors.green,
              ]),
        ),
        child: Column(
          children: <Widget>[
            Text(
              'Money: ',
              style: const TextStyle(fontSize: 30),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () {},
                  child: const Icon(Icons.list),
                ),
                ElevatedButton(
                  onPressed: () {},
                  child: Text("Back"),
                ),
              ],
            ),
            Expanded(
              child: ListView.builder(
                itemCount: abilitiesList.length,
                itemBuilder: (context, index) {
                  return Card(
                    color: const Color(0xDDFFFFFF),
                    elevation: 4,
                    child: ListTile(
                      onTap: () {},
                      title: Text("Name"),
                      subtitle: Text("Cost:"),
                      trailing: ElevatedButton(
                        onPressed: () {},
                        child: const Text("Buy"),
                      ),
                    ),
                  );
                },
              ),
            )
          ],
        ),
      ),
    );
  }
}
