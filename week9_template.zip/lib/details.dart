import 'package:flutter/material.dart';
import 'globals.dart';

class DetailsPage extends StatelessWidget {
  const DetailsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ability Details'),
      ),
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.white,
                Color.fromARGB(255, 255, 138, 138),
              ]),
        ),
        child: Column(children: [
          Text(
            "Ability: ",
            style: const TextStyle(fontSize: 30),
          ),
          Text(
            "Cost: ",
            style: const TextStyle(fontSize: 30),
          ),
          ElevatedButton(
            onPressed: () {},
            child: const Text('Go Back with Stuff'),
          ),
        ]),
      ),
    );
  }
}
